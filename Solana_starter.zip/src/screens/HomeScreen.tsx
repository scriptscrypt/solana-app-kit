import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, SafeAreaView } from 'react-native';
import Tweet from '../components/tweet/tweet';
import UserListing from '../components/userListing/userListing';
import SuggestionsCard from '../components/suggestionsCard/sugegstionsCard';
import { tweetsData } from '../mocks/tweets';
import { RootStackParamList } from '../navigation/RootNavigator';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';


type HomeScreenNavigationProp = StackNavigationProp<RootStackParamList>;
export const STRINGS = {
  HOME: {
    TITLE: 'Home Screen',
    COIN_DETAILS_LINK: 'Go To Coin Details'
  }
};


export default function HomeScreen() {
  const navigation = useNavigation<HomeScreenNavigationProp>();
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.text}>{STRINGS.HOME.TITLE}</Text>
      {/* <SuggestionsCard/> */}
      {/* <UserListing/> */}
      {/* <Tweet/> */}
      <TouchableOpacity onPress={() => navigation.navigate('CoinDetailPage')}>
        <Text>{STRINGS.HOME.COIN_DETAILS_LINK}</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#ffffff' },
  text: { fontSize: 20 },
});

import React from 'react'
import { View, Text } from 'react-native'

export const LatestScreen = () => {
  return (
    <View>
      <Text>Latest Section</Text>
    </View>
  )
}

import React from 'react'
import { View, Text } from 'react-native'

export const PhotosScreen = () => {
  return (
    <View>
      <Text>Photos Section</Text>
    </View>
  )
}

import React from 'react'
import { View, Text } from 'react-native'
import { WalletCard } from '../../../../components/WalletCard'

export const LatestScreen = () => {
  return (
    <View>
      <Text>Latest Section</Text>
 
    </View>
  )
}

// <WalletCard
// balance={10548}
// priceChange={0.00021113}
// percentageChange={4.77}
// onSwap={() => {/* handle swap */ }}
// onSend={() => {/* handle send */ }}
// onRamp={() => {/* handle on-ramp */ }}
// />
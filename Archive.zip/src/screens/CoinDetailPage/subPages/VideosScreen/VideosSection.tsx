import React from 'react'
import { View, Text } from 'react-native'

export const VideosScreen = () => {
  return (
    <View>
      <Text>Videos Section</Text>
    </View>
  )
}
